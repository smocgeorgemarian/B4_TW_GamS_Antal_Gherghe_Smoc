
function setSpinnable(object) {
    // object.classList.remove("fa fa-home");
}

//Form Manager
// function openForm() {
//     document.getElementById("reportForm").style.display = "block";
// }
//
// function closeForm() {
//     document.getElementById("reportForm").style.display = "none";
// }
